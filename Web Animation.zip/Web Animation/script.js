// This is the decleration of the varaibles need for the animated object
let counter;
let interval_forward;
let interval_backward;
// This function justr checks if the scroll bar is at the botytom of the screen
function isScrollBarAtBottom(container) {
  return (
    container.scrollTop === container.scrollHeight - container.clientHeight
  );
}
// This function simply starts the animation transition baased on the scroll bar's position
function move() {
  const container = document.querySelector(".container");
  if (isScrollBarAtBottom(container)) {
    counter = 1;
    interval_forward = setInterval(play_animation_forward, 50);
  } else if (container.scrollTop === 0) {
    counter = 60;
    interval_backward = setInterval(play_animation_backwards, 50);
  }
}
// This just swaps the images frame by frame
function updateBackgroundImage(imageIndex) {
  const image_string = ("0000" + imageIndex).slice(-4);
  const imageURL = `Images/${image_string}-min.png`;
  document.querySelector(
    ".container"
  ).style.backgroundImage = `url(${imageURL})`;
}
// This plays the animaton forward
function play_animation_forward() {
  updateBackgroundImage(counter);
  counter++;
  if (counter > 60) clearInterval(interval_forward);
}
// This plays the animation backwards
function play_animation_backwards() {
  updateBackgroundImage(counter);
  counter--;
  if (counter <= 1) clearInterval(interval_backward);
}
// This just starts the page 
function start_page() {
  counter = 1
  updateBackgroundImage(counter)
}
document.addEventListener("DOMContentLoaded", start_page);
